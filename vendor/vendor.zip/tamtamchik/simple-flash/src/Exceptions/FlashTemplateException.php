<?php

namespace Tamtamchik\SimpleFlash\Exceptions;

/**
 * Class FlashTemplateException.
 * Thrown when there is a problem with template class.
 */
class FlashTemplateException extends \Exception { }
