<ul>
    <li>
        <a href="./bootstrap4.php">Bootstrap 4</a>
        [<a target="_blank" href="http://getbootstrap.com">http://getbootstrap.com</a>]
    </li>
    <li>
        <a href="./bootstrap3.php">Bootstrap 3</a>
        [<a target="_blank" href="https://getbootstrap.com/docs/3.3">https://getbootstrap.com/docs/3.3</a>]
    </li>
    <li>
        <a href="./foundation6.php">Foundation 6</a>
        [<a target="_blank" href="http://foundation.zurb.com">http://foundation.zurb.com</a>]
    </li>
    <li>
        <a href="./foundation5.php">Foundation 5</a>
        [<a target="_blank" href="http://foundation.zurb.com/sites/docs/v/5.5.3">http://foundation.zurb.com/sites/docs/v/5.5.3</a>]
    </li>
    <li>
        <a href="./semantic2.php">Semantic UI 2</a>
        [<a target="_blank" href="https://semantic-ui.com">https://semantic-ui.com</a>]
    </li>
    <li>
        <a href="./uikit3.php">UIKit 3</a>
        [<a target="_blank" href="https://getuikit.com">https://getuikit.com</a>]
    </li>
    <li>
        <a href="./uikit2.php">UIKit 2</a>
        [<a target="_blank" href="https://getuikit.com/v2/">https://getuikit.com/v2/</a>]
    </li>
    <li>
        <a href="./siimple3.php">Siimple 3</a>
        [<a target="_blank" href="https://www.siimple.xyz">https://www.siimple.xyz</a>]
    </li>
    <li>
        <a href="./siimple2.php">Siimple 2</a>
        [<a target="_blank" href="https://github.com/siimple/siimple/releases/tag/v2.0.1">https://github.com/siimple/siimple/releases/tag/v2.0.1</a>]
    </li>
    <li>
        <a href="./siimple.php">Siimple</a>
        [<a target="_blank" href="https://github.com/siimple/siimple/releases/tag/v1.3.7">https://github.com/siimple/siimple/releases/tag/v1.3.7</a>]
    </li>
    <li>
        <a href="./bulma.php">Bulma</a>
        [<a target="_blank" href="http://bulma.io">http://bulma.io</a>]
    </li>
    <li>
        <a href="./materialize.php">Materialize</a>
        [<a target="_blank" href="https://materializecss.com">https://materializecss.com</a>]
    </li>
    <li>
        <a href="./spectre.php">Spectre.css</a>
        [<a target="_blank" href="https://picturepan2.github.io/spectre/">https://picturepan2.github.io/spectre/</a>]
    </li>
    <li>
        <a href="./tailwind.php">Tailwind</a>
        [<a target="_blank" href="https://tailwindcss.com">https://tailwindcss.com</a>]
    </li>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/tailwind.min.css" rel="stylesheet">

    <li><a href="./custom.php">Custom Template</a></li>
</ul>
