---
layout: documentation
current_menu: enterprise-support
---

# Support

Basic support is provided through [Gitter](https://gitter.im/PHP-DI/PHP-DI) and [StackOverflow using the `php-di` tag](https://stackoverflow.com/questions/tagged/php-di).

## Enterprise support

If you want to support the project and benefit from enterprise support and service please send me a line at `matthieu at mnapoli.fr`.
